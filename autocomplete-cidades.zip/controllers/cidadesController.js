const fs = require('fs');
const path = require('path');

//Globais
let cidades = [];
let fuse = null;
let carregando = true;

async function carregarCidades(){
    try{
        const CIDADES_JSON = path.join(__dirname, '../public/assets/json/cidades.json');
        const data = await  fs.promises.readFile(CIDADES_JSON, 'utf-8');
        cidades = JSON.parse(data);
        const Fuse = ( await import('fuse.js')).default;
        fuse = new Fuse(cidades, {
            keys: [
                { name: 'alias', weight: 0.8 },
                { name: 'municipio', weight: 0.5 },
                { name: 'estado', weight: 0.3 },
                { name: 'uf', weight: 0.1 },
                { name: 'regiao', weight: 0.1 }
            ],
            threshold: 0.2,
            distance: 100,
            useExtendedSearch: true,
            includeScore: false,
            shouldSort: true
        });
        carregando = false;
        console.log(`✅ ${cidades.length} cidades carregadas e indexadas com Fuse.js`);

    }catch(err){
        carregando = false;
        fuse = null;
        console.log('Erro ao carregar cidades.json', err.message)
    }
}

module.exports = {
    carregarCidades,
    get cidades(){ return cidades; }, //getter seguro//
    get fuse(){ return fuse; },     //*** *//
    get carregando(){ return carregando; } //*** */
};
