const  express = require("express");
const fs = require('fs');
const path = require('path');
const app =  express();
const  PORT = 3001;
const CIDADES_JSON = path.join(__dirname, 'public/assets/json/cidades.json');
app.use(express.static('public'));
app.use('/assets', express.static(path.join(__dirname, 'public/assets')));
app.get('/busca', (req, res)=>{
    res.sendFile(path.join(__dirname, 'public', 'busca.html'))
})



let cidades = [];
let fuse;

async function carregarCidades(){
    try{
        const data = await  fs.promises.readFile(CIDADES_JSON, 'utf-8');
        cidades = JSON.parse(data);
        const Fuse = ( await import('fuse.js')).default;
        fuse = new Fuse(cidades, {
            keys: [
                { name: 'alias', weight: 0.8 },
                { name: 'municipio', weight: 0.5 },
                { name: 'estado', weight: 0.3 },
                { name: 'uf', weight: 0.1 },
                { name: 'regiao', weight: 0.1 }
            ],
            threshold: 0.2,
            distance: 100,
            useExtendedSearch: true,
            includeScore: false
        });
        carregando = false;
        console.log(`✅ ${cidades.length} cidades carregadas e indexadas com Fuse.js`);

    }catch(err){
        carregando = false;
        fuse = null;
        console.log('Erro ao carregar cidades.json', err.message)
    }
}

carregarCidades();

//ROTA: GET /api/cidades?termo=sa //
app.get("/api/cidades", (req, res) => {
   const termo = req.query.termo?.trim();
    // Validacao
    if(!termo || termo.length < 2){
        return res.json([]);
    }
    //caregamento//
    if(carregando){
        return res.status(503).json({
            error: 'Sistema caregando, tente novamente em alguns segundos.'
        });
    }
    //ver.. falha//
    if(!fuse){
        return res.status(500).json({
            error: 'Busca indisponivel. Dados nao foram carregados.'
        })
    }
    //Busca//
    try{
        const resultados = fuse.search(termo);
        const dados = resultados.map(r => r.item).slice(0, 10);
        return res.json(dados);

    }catch(err){
            console.error('Erro na busca:', err);
            res.status(500).json({ error: 'Erro interno na busca' });
    }
});

app.listen(PORT, ()=>{
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
})